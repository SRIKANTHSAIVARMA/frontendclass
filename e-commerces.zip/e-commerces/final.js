const cart = {}; // To store cart items
const cartItem = document.querySelector('.cart-items');
const cartTotal = document.querySelector('.cart-total');
const addToCartButtons = document.querySelectorAll('.add-to-cart');
const checkoutButton = document.querySelector('.checkout-btn');

// Updates the cart display
function updateCart() {
  cartItem.innerHTML = '';
  let total = 0;
  for (const item in cart) {
    total += cart[item].price * cart[item].quantity;
    cartItem.innerHTML += `
      <li>
        ${item} - $${cart[item].price} x ${cart[item].quantity}
        <button class="increase" data-name="${item}">+</button>
        <button class="decrease" data-name="${item}">-</button>
        <button class="remove" data-name="${item}">Remove</button>
      </li>`;
  }

  cartTotal.textContent = `Total: $${total.toFixed(2)}`;
}

// Adds an item to the cart
function addToCart(name, price) {
  cart[name] = cart[name] || { price, quantity: 0 };
  cart[name].quantity++;
  updateCart();
}

// Attach events to "Add to Cart" buttons
addToCartButtons.forEach(button => {
  button.addEventListener('click', () => {
    const name = button.getAttribute('data-name');
    const price = parseFloat(button.getAttribute('data-price'));
    addToCart(name, price);
  });
});

// Handle cart actions (increase, decrease, remove)
cartItem.addEventListener('click', event => {
  const name = event.target.getAttribute('data-name');
  if (event.target.classList.contains('increase')) cart[name].quantity++;
  if (event.target.classList.contains('decrease')) {
    cart[name].quantity--;
    if (cart[name].quantity <= 0) delete cart[name];
  }
  if (event.target.classList.contains('remove')) delete cart[name];
  updateCart();
});

// Handle checkout
checkoutButton.addEventListener('click', () => {
  if (Object.keys(cart).length === 0) return alert('Your cart is empty!');
  alert('Thank you for your purchase!');
  Object.keys(cart).forEach(key => delete cart[key]);
  updateCart();
});
